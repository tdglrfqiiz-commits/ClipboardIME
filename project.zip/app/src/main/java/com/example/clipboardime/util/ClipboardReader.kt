package com.example.clipboardime.util

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.util.Log

/**
 * 剪贴板读取工具，尽量完整地取出文本，避免 Binder 传输截断。
 *
 * 读取策略（按优先级）：
 * 1. 直接读取 ClipData 中的 CharSequence 文本 —— 覆盖 95% 的场景。
 * 2. 如果是 content:// URI，尝试通过 ContentResolver 打开输入流读取。
 * 3. 如果 item.text 为 null 但 item.uri 存在，同样走流式读取。
 *
 * 注意：Android 10+ 只有默认输入法或前台应用才能读取剪贴板，
 *       本应用作为默认输入法可以正常读取，无需额外权限。
 */
object ClipboardReader {

    private const val TAG = "ClipboardReader"

    /**
     * 读取剪贴板全部文本。返回 null 表示没有文本内容。
     */
    fun readText(context: Context, clipboard: ClipboardManager): String? {
        val clip: ClipData = clipboard.primaryClip ?: return null
        if (clip.itemCount == 0) return null

        val item = clip.getItemAt(0)

        // 策略 1：直接读取文本
        item.text?.let { text ->
            val s = text.toString()
            if (s.isNotEmpty()) return s
        }

        // 策略 2：通过 URI 读取（处理某些应用通过 ContentProvider 放大的文本）
        item.uri?.let { uri ->
            readFromUri(context, uri)?.let { return it }
        }

        return null
    }

    /**
     * 通过 ContentResolver 从 content:// URI 读取完整文本。
     * 用流式读取避免一次性加载过大内容。
     */
    private fun readFromUri(context: Context, uri: Uri): String? {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                input.bufferedReader(Charsets.UTF_8).readText()
            }
        } catch (e: Exception) {
            Log.w(TAG, "无法从 URI 读取剪贴板内容: $uri", e)
            null
        }
    }
}