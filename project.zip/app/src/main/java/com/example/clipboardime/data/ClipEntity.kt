package com.example.clipboardime.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 一条剪贴板记录。
 *
 * 设计要点：
 * - text 字段通常直接存文本内容。
 * - 如果文本超过 [LargeTextStore.THRESHOLD_BYTES]（500KB），
 *   text 字段只存 "__FILE__:<文件路径>"，完整内容存本地文件，
 *   避免 SQLite CursorWindow 2MB 限制导致查询崩溃。
 * - contentHash 用于去重，防止连续复制同一内容产生重复记录。
 * - isPinned 置顶标记，置顶的记录永远排在列表最前面。
 */
@Entity(tableName = "clip_history")
data class ClipEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    /** 文本预览（前 N 个字符），用于列表显示 */
    @ColumnInfo(name = "preview")
    val preview: String,

    /** 完整文本；超大文本时存 "__FILE__:路径" */
    @ColumnInfo(name = "text")
    val text: String,

    /** 内容哈希（SHA-256 前 16 位），用于去重 */
    @ColumnInfo(name = "content_hash")
    val contentHash: String,

    /** 是否为超大文本（内容在文件中而非数据库） */
    @ColumnInfo(name = "is_large")
    val isLarge: Boolean = false,

    /** 是否置顶 */
    @ColumnInfo(name = "is_pinned")
    val isPinned: Boolean = false,

    /** 创建时间戳（毫秒） */
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
)