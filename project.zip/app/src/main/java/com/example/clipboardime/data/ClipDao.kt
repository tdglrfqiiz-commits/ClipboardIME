package com.example.clipboardime.data

import androidx.room.*

/**
 * 剪贴板历史的数据访问接口。
 * Room 会自动生成实现类，无需手写 SQL 执行逻辑。
 */
@Dao
interface ClipDao {

    /**
     * 查询所有记录。
     * 排序规则：置顶的永远在前，其余按时间倒序（最新的在最上面）。
     */
    @Query("SELECT * FROM clip_history ORDER BY is_pinned DESC, created_at DESC")
    fun getAll(): List<ClipEntity>

    /** 带关键词的搜索，同时对预览和完整文本模糊匹配 */
    @Query("""
        SELECT * FROM clip_history 
        WHERE preview LIKE '%' || :keyword || '%' 
           OR text LIKE '%' || :keyword || '%'
        ORDER BY is_pinned DESC, created_at DESC
    """)
    fun search(keyword: String): List<ClipEntity>

    /** 根据内容哈希查重 */
    @Query("SELECT * FROM clip_history WHERE content_hash = :hash LIMIT 1")
    fun findByHash(hash: String): ClipEntity?

    /** 插入一条记录，返回新行的 id */
    @Insert
    fun insert(entity: ClipEntity): Long

    /** 删除指定记录 */
    @Delete
    fun delete(entity: ClipEntity)

    /** 切换置顶状态 */
    @Query("UPDATE clip_history SET is_pinned = :pinned WHERE id = :id")
    fun setPinned(id: Long, pinned: Boolean)

    /** 删除全部记录（可选功能） */
    @Query("DELETE FROM clip_history")
    fun deleteAll()
}