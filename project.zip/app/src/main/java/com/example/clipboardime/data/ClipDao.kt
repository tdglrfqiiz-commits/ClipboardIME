package com.example.clipboardime.data

import androidx.room.*

@Dao
interface ClipDao {

    @Query("SELECT * FROM clip_history ORDER BY is_pinned DESC, created_at DESC")
    fun getAll(): List<ClipEntity>

    @Query("SELECT * FROM clip_history WHERE content_hash = :hash LIMIT 1")
    fun findByHash(hash: String): ClipEntity?

    @Insert
    fun insert(entity: ClipEntity): Long

    @Delete
    fun delete(entity: ClipEntity)

    @Query("UPDATE clip_history SET is_pinned = :pinned WHERE id = :id")
    fun setPinned(id: Long, pinned: Boolean)

    // ★ 新增：更新记录的时间戳，使其重新排到最前面
    @Query("UPDATE clip_history SET created_at = :time WHERE id = :id")
    fun updateTimestamp(id: Long, time: Long)

    @Query("DELETE FROM clip_history")
    fun deleteAll()
}