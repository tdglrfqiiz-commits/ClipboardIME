package com.example.clipboardime.data

import android.content.Context
import com.example.clipboardime.util.LargeTextStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

class ClipRepository(private val context: Context) {

    private val dao = ClipDatabase.get(context).clipDao()
    private val largeStore = LargeTextStore(context)

    suspend fun save(text: String) {
        withContext(Dispatchers.IO) {
            val hash = sha256(text).take(16)

            // ★ 修改去重逻辑：如果存在相同内容，不再忽略，而是更新时间戳让它置顶
            val existing = dao.findByHash(hash)
            if (existing != null) {
                Log.d("ClipRepository", "内容已存在，更新时间戳使其置顶")
                dao.updateTimestamp(existing.id, System.currentTimeMillis())
                return@withContext
            }

            val isLarge = text.toByteArray(Charsets.UTF_8).size > LargeTextStore.THRESHOLD_BYTES

            val entity: ClipEntity
            if (isLarge) {
                val filePath = largeStore.saveToFile(text)
                entity = ClipEntity(
                    preview = text.take(100).replace("\n", " "),
                    text = LargeTextStore.FILE_PREFIX + filePath,
                    contentHash = hash,
                    isLarge = true
                )
            } else {
                entity = ClipEntity(
                    preview = text.take(100).replace("\n", " "),
                    text = text,
                    contentHash = hash,
                    isLarge = false
                )
            }
            dao.insert(entity)
        }
    }

    suspend fun getFullText(entity: ClipEntity): String = withContext(Dispatchers.IO) {
        if (entity.isLarge && entity.text.startsWith(LargeTextStore.FILE_PREFIX)) {
            val path = entity.text.removePrefix(LargeTextStore.FILE_PREFIX)
            largeStore.readFromFile(path)
        } else {
            entity.text
        }
    }

    suspend fun getAll(): List<ClipEntity> = withContext(Dispatchers.IO) { dao.getAll() }

    suspend fun delete(entity: ClipEntity) = withContext(Dispatchers.IO) {
        if (entity.isLarge && entity.text.startsWith(LargeTextStore.FILE_PREFIX)) {
            largeStore.deleteFile(entity.text.removePrefix(LargeTextStore.FILE_PREFIX))
        }
        dao.delete(entity)
    }

    suspend fun togglePin(entity: ClipEntity) = withContext(Dispatchers.IO) {
        dao.setPinned(entity.id, !entity.isPinned)
    }

    private fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(input.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}