package com.example.clipboardime.data

import android.content.Context
import com.example.clipboardime.util.LargeTextStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/**
 * 仓库层：封装“保存剪贴板记录”和“读取完整文本”的逻辑。
 *
 * 核心职责：
 * 1. 判断文本是否超大，决定存数据库还是存文件。
 * 2. 去重。
 * 3. 读取时，如果是超大文本则从文件加载完整内容。
 */
class ClipRepository(private val context: Context) {

    private val dao = ClipDatabase.get(context).clipDao()
    private val largeStore = LargeTextStore(context)

    /**
     * 保存一条剪贴板文本。
     * 如果内容与最近一条完全相同，跳过（去重）。
     */
    suspend fun save(text: String) {
        withContext(Dispatchers.IO) {
            // 1. 计算哈希
            val hash = sha256(text).take(16)

            // 2. 查重：如果已存在同哈希的记录，不重复保存
            if (dao.findByHash(hash) != null) return@withContext

            // 3. 判断是否超大
            val isLarge = text.toByteArray(Charsets.UTF_8).size > LargeTextStore.THRESHOLD_BYTES

            val entity: ClipEntity
            if (isLarge) {
                // 超大文本：写入本地文件，数据库只存路径
                val filePath = largeStore.saveToFile(text)
                entity = ClipEntity(
                    preview = text.take(100).replace("\n", " "),
                    text = LargeTextStore.FILE_PREFIX + filePath,
                    contentHash = hash,
                    isLarge = true
                )
            } else {
                // 普通文本：直接存数据库
                entity = ClipEntity(
                    preview = text.take(100).replace("\n", " "),
                    text = text,
                    contentHash = hash,
                    isLarge = false
                )
            }
            dao.insert(entity)
        }
    }

    /**
     * 获取某条记录的完整文本。
     * 如果是超大文本，从文件读取；否则直接返回数据库中的文本。
     */
    suspend fun getFullText(entity: ClipEntity): String = withContext(Dispatchers.IO) {
        if (entity.isLarge && entity.text.startsWith(LargeTextStore.FILE_PREFIX)) {
            val path = entity.text.removePrefix(LargeTextStore.FILE_PREFIX)
            largeStore.readFromFile(path)
        } else {
            entity.text
        }
    }

    suspend fun getAll(): List<ClipEntity> = withContext(Dispatchers.IO) { dao.getAll() }

    suspend fun search(keyword: String): List<ClipEntity> =
        withContext(Dispatchers.IO) { dao.search(keyword) }

    suspend fun delete(entity: ClipEntity) = withContext(Dispatchers.IO) {
        // 如果是对大文本，顺便删除本地文件
        if (entity.isLarge && entity.text.startsWith(LargeTextStore.FILE_PREFIX)) {
            largeStore.deleteFile(entity.text.removePrefix(LargeTextStore.FILE_PREFIX))
        }
        dao.delete(entity)
    }

    suspend fun togglePin(entity: ClipEntity) = withContext(Dispatchers.IO) {
        dao.setPinned(entity.id, !entity.isPinned)
    }

    private fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(input.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}