package com.example.clipboardime.data

import android.content.Context
import android.util.Log // ★ 新增：修复 Unresolved reference 'Log' 报错
import com.example.clipboardime.util.LargeTextStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

/**
 * 仓库层：封装“保存剪贴板记录”和“读取完整文本”的逻辑。
 */
class ClipRepository(private val context: Context) {

    private val dao = ClipDatabase.get(context).clipDao()
    private val largeStore = LargeTextStore(context)

    /**
     * 保存一条剪贴板文本。
     * 如果内容已存在，更新其时间戳让其排到最前面。
     */
    suspend fun save(text: String) {
        withContext(Dispatchers.IO) {
            val hash = sha256(text).take(16)

            // ★ 修改去重逻辑：如果存在相同内容，不再忽略，而是更新时间戳让它置顶
            val existing = dao.findByHash(hash)
            if (existing != null) {
                Log.d("ClipRepository", "内容已存在，更新时间戳使其置顶")
                dao.updateTimestamp(existing.id, System.currentTimeMillis())
                return@withContext
            }

            // 判断是否超过 500KB
            val isLarge = text.toByteArray(Charsets.UTF_8).size > LargeTextStore.THRESHOLD_BYTES

            val entity: ClipEntity
            if (isLarge) {
                // 超大文本：写入本地文件，数据库只存路径
                val filePath = largeStore.saveToFile(text)
                entity = ClipEntity(
                    preview = text.take(100).replace("\n", " "),
                    text = LargeTextStore.FILE_PREFIX + filePath,
                    contentHash = hash,
                    isLarge = true
                )
            } else {
                // 普通文本：直接存数据库
                entity = ClipEntity(
                    preview = text.take(100).replace("\n", " "),
                    text = text,
                    contentHash = hash,
                    isLarge = false
                )
            }
            dao.insert(entity)
        }
    }

    /**
     * 获取某条记录的完整文本。
     * 如果是超大文本，从文件读取；否则直接返回数据库中的文本。
     */
    suspend fun getFullText(entity: ClipEntity): String = withContext(Dispatchers.IO) {
        if (entity.isLarge && entity.text.startsWith(LargeTextStore.FILE_PREFIX)) {
            val path = entity.text.removePrefix(LargeTextStore.FILE_PREFIX)
            largeStore.readFromFile(path)
        } else {
            entity.text
        }
    }

    suspend fun getAll(): List<ClipEntity> = withContext(Dispatchers.IO) { dao.getAll() }

    suspend fun delete(entity: ClipEntity) = withContext(Dispatchers.IO) {
        // 如果是对大文本，顺便删除本地文件
        if (entity.isLarge && entity.text.startsWith(LargeTextStore.FILE_PREFIX)) {
            largeStore.deleteFile(entity.text.removePrefix(LargeTextStore.FILE_PREFIX))
        }
        dao.delete(entity)
    }

    suspend fun togglePin(entity: ClipEntity) = withContext(Dispatchers.IO) {
        dao.setPinned(entity.id, !entity.isPinned)
    }

    private fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(input.toByteArray()).joinToString("") { "%02x".format(it) }
    }
}