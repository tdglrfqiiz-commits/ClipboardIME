package com.example.clipboardime.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.clipboardime.R
import com.example.clipboardime.data.ClipEntity

/**
 * 剪贴板历史列表的 RecyclerView 适配器。
 *
 * 每条记录显示：预览文本、时间、置顶按钮、删除按钮。
 * 点击条目本身 → 触发粘贴回调。
 */
class ClipAdapter(
    private val onItemClick: (ClipEntity) -> Unit,
    private val onDeleteClick: (ClipEntity) -> Unit,
    private val onPinClick: (ClipEntity) -> Unit
) : RecyclerView.Adapter<ClipAdapter.VH>() {

    private val items = mutableListOf<ClipEntity>()

    /** 提交新列表，局部刷新 */
    fun submit(list: List<ClipEntity>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_clip, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int = items.size

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val preview: TextView = itemView.findViewById(R.id.tv_preview)
        private val time: TextView = itemView.findViewById(R.id.tv_time)
        private val btnDelete: ImageButton = itemView.findViewById(R.id.btn_delete)
        private val btnPin: ImageButton = itemView.findViewById(R.id.btn_pin)

        fun bind(entity: ClipEntity) {
            // 预览文本
            preview.text = entity.preview.ifBlank { "(空)" }

            // 时间显示
            time.text = formatTime(entity.createdAt)

            // 置顶图标：置顶时显示实心星，未置顶显示空心星
            btnPin.setImageResource(
                if (entity.isPinned) android.R.drawable.btn_star_big_on
                else android.R.drawable.btn_star_big_off
            )

            // 点击条目 → 粘贴
            itemView.setOnClickListener { onItemClick(entity) }

            // 删除
            btnDelete.setOnClickListener { onDeleteClick(entity) }

            // 置顶/取消置顶
            btnPin.setOnClickListener { onPinClick(entity) }
        }

        private fun formatTime(ts: Long): String {
            val diff = System.currentTimeMillis() - ts
            return when {
                diff < 60_000 -> "刚刚"
                diff < 3_600_000 -> "${diff / 60_000} 分钟前"
                diff < 86_400_000 -> "${diff / 3_600_000} 小时前"
                diff < 2_592_000_000 -> "${diff / 86_400_000} 天前"
                else -> {
                    val sdf = java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.getDefault())
                    sdf.format(java.util.Date(ts))
                }
            }
        }
    }
}