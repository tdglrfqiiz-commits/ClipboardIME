package com.example.clipboardime.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.clipboardime.R
import com.example.clipboardime.data.ClipEntity

class ClipAdapter(
    private val onItemClick: (ClipEntity) -> Unit,
    private val onDeleteClick: (ClipEntity) -> Unit,
    private val onPinClick: (ClipEntity) -> Unit
) : RecyclerView.Adapter<ClipAdapter.VH>() {

    private val items = mutableListOf<ClipEntity>()

    fun submit(list: List<ClipEntity>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_clip, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int = items.size

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val preview: TextView = itemView.findViewById(R.id.tv_preview)
        private val time: TextView = itemView.findViewById(R.id.tv_time)
        private val btnDelete: ImageButton = itemView.findViewById(R.id.btn_delete)
        private val btnPin: ImageButton = itemView.findViewById(R.id.btn_pin)

        fun bind(entity: ClipEntity) {
            preview.text = entity.preview.ifBlank { "(空)" }
            time.text = formatTime(entity.createdAt)

            btnPin.setImageResource(
                if (entity.isPinned) android.R.drawable.btn_star_big_on
                else android.R.drawable.btn_star_big_off
            )

            itemView.setOnClickListener { onItemClick(entity) }
            btnDelete.setOnClickListener { onDeleteClick(entity) }
            btnPin.setOnClickListener { onPinClick(entity) }
        }

        private fun formatTime(ts: Long): String {
            val diff = System.currentTimeMillis() - ts
            return when {
                diff < 60_000 -> "刚刚"
                diff < 3_600_000 -> "${diff / 60_000} 分钟前"
                diff < 86_400_000 -> "${diff / 3_600_000} 小时前"
                diff < 2_592_000_000 -> "${diff / 86_400_000} 天前"
                else -> {
                    val sdf = java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.getDefault())
                    sdf.format(java.util.Date(ts))
                }
            }
        }
    }
}