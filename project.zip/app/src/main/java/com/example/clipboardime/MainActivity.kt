package com.example.clipboardime

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

/**
 * 引导页。
 * 告诉用户如何启用输入法、如何切换默认输入法。
 * 本身不承担剪贴板功能，所有核心逻辑在 ClipboardInputMethodService 中。
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 打开系统输入法设置页面（Android 10+ 用 Settings.ACTION_INPUT_METHOD_SETTINGS）
        findViewById<Button>(R.id.btn_open_ime_settings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        // 弹出输入法选择器，让用户切换默认输入法
        findViewById<Button>(R.id.btn_pick_ime).setOnClickListener {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }
    }
}