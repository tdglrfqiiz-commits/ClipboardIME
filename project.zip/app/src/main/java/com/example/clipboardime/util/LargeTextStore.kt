package com.example.clipboardime.util

import android.content.Context
import java.io.File

/**
 * 超大文本的文件存储工具。
 *
 * 为什么需要这个？
 * Android 的 SQLite 查询结果通过 CursorWindow 传输，默认上限约 2MB。
 * 如果单条文本超过这个限制，查询会抛 SQLiteBlobTooBigException。
 * 所以超过 [THRESHOLD_BYTES] 的文本改为存文件，数据库只存文件路径。
 *
 * 文件放在应用私有目录 files/clip_large/ 下，不需要任何存储权限。
 */
class LargeTextStore(private val context: Context) {

    companion object {
        /** 超过 500KB 的文本存为文件 */
        const val THRESHOLD_BYTES = 500 * 1024

        /** 数据库 text 字段以这个前缀开头表示内容在文件中 */
        const val FILE_PREFIX = "__FILE__:"
    }

    private val dir: File by lazy {
        File(context.filesDir, "clip_large").also { it.mkdirs() }
    }

    /** 把完整文本写入文件，返回文件绝对路径 */
    fun saveToFile(text: String): String {
        val file = File(dir, "clip_${System.currentTimeMillis()}_${text.hashCode()}.txt")
        file.writeText(text, Charsets.UTF_8)
        return file.absolutePath
    }

    /** 从文件读取完整文本 */
    fun readFromFile(path: String): String {
        val file = File(path)
        return if (file.exists()) file.readText(Charsets.UTF_8) else ""
    }

    /** 删除文件 */
    fun deleteFile(path: String) {
        runCatching { File(path).delete() }
    }
}