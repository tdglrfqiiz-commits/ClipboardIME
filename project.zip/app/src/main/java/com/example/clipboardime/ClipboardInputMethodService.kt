package com.example.clipboardime

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.ImageButton
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.clipboardime.data.ClipEntity
import com.example.clipboardime.data.ClipRepository
import com.example.clipboardime.ui.ClipAdapter
import com.example.clipboardime.util.ClipboardReader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ClipboardInputMethodService : InputMethodService() {

    companion object {
        private const val TAG = "ClipIME"
        private const val COMMIT_CHUNK_SIZE = 256 * 1024
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var repository: ClipRepository
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var adapter: ClipAdapter

    private var currentList: List<ClipEntity> = emptyList()
    private var lastSavedText: String? = null
    private var lastSaveTime: Long = 0L

    // ★ 保存根布局视图引用，用于拖拽时改变位置
    private var inputView: View? = null

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val text = ClipboardReader.readText(this, clipboardManager) ?: return@OnPrimaryClipChangedListener
        if (text.isBlank()) return@OnPrimaryClipChangedListener

        val now = System.currentTimeMillis()
        // 1秒内相同内容不重复保存
        if (text == lastSavedText && now - lastSaveTime < 1000) {
            return@OnPrimaryClipChangedListener
        }
        lastSavedText = text
        lastSaveTime = now

        scope.launch {
            repository.save(text)
            refreshList()
        }
    }

    override fun onCreate() {
        super.onCreate()
        repository = ClipRepository(this)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager.addPrimaryClipChangedListener(clipListener)

        // ★ 修复“删除后复活”：只在输入法初始化时补读一次剪贴板，
        // 之后再也不用 onStartInput 去读剪贴板，避免删掉的记录又被重新存回来。
        val initialText = ClipboardReader.readText(this, clipboardManager)
        if (!initialText.isNullOrBlank()) {
            lastSavedText = initialText
            lastSaveTime = System.currentTimeMillis()
            scope.launch { repository.save(initialText) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        clipboardManager.removePrimaryClipChangedListener(clipListener)
        scope.cancel()
    }

    /**
     * 限制输入法窗口高度为屏幕的 40%
     */
    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val screenHeight = resources.displayMetrics.heightPixels
        val targetHeight = (screenHeight * 0.4).toInt()
        // ★ 这里必须用 window?.window 拿到真正的窗口对象
        window?.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, targetHeight)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.ime_clipboard, null)
        inputView = view

        // 强制设置视图高度，双保险
        val screenHeight = resources.displayMetrics.heightPixels
        val targetHeight = (screenHeight * 0.4).toInt()
        view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, targetHeight)

        val recycler = view.findViewById<RecyclerView>(R.id.clip_recycler)
        adapter = ClipAdapter(
            onItemClick = { entity -> commitClipText(entity) },
            onDeleteClick = { entity -> deleteClip(entity) },
            onPinClick = { entity -> togglePin(entity) }
        )
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val switchBtn = view.findViewById<ImageButton>(R.id.btn_switch_ime)
        switchBtn.setOnClickListener { switchToDefaultIme() }

        // ★ 启用跟手拖拽手势
        val dragHandle = view.findViewById<View>(R.id.drag_handle)
        setupDragToClose(dragHandle)

        refreshList()
        return view
    }

    /**
     * ★ 重写：跟手拖拽 + 松手回弹/关闭
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupDragToClose(dragHandle: View) {
        var startY = 0f
        val screenHeight = resources.displayMetrics.heightPixels
        // 触发关闭的阈值：屏幕高度的 1/4，或者固定 200px（取较大值保证手感）
        val dismissThreshold = maxOf(screenHeight / 4, 200)

        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = event.rawY - startY
                    // 只允许向下拖拽（dy > 0），向上拖不响应
                    if (dy > 0) {
                        // 把手指的位移应用到整个输入法面板上，实现跟手
                        inputView?.translationY = dy
                    } else {
                        inputView?.translationY = 0f
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dy = event.rawY - startY
                    if (dy > dismissThreshold) {
                        // 滑动距离超过阈值，隐藏输入法
                        requestHideSelf(0)
                    } else {
                        // 没超过阈值，用动画平滑弹回原位
                        inputView?.animate()
                            ?.translationY(0f)
                            ?.setDuration(200)
                            ?.start()
                    }
                    startY = 0f
                    true
                }
                else -> false
            }
        }
    }

    private fun refreshList() {
        scope.launch {
            currentList = repository.getAll()
            adapter.submit(currentList)
        }
    }

    private fun deleteClip(entity: ClipEntity) {
        scope.launch {
            repository.delete(entity)
            refreshList()
        }
    }

    private fun togglePin(entity: ClipEntity) {
        scope.launch {
            repository.togglePin(entity)
            refreshList()
        }
    }

    private fun commitClipText(entity: ClipEntity) {
        scope.launch {
            val fullText = withContext(Dispatchers.IO) {
                repository.getFullText(entity)
            }
            if (fullText.isEmpty()) {
                showToast("内容为空")
                return@launch
            }

            val ic: InputConnection = currentInputConnection ?: run {
                showToast("当前没有可输入的输入框")
                return@launch
            }

            try {
                if (fullText.length <= COMMIT_CHUNK_SIZE) {
                    ic.commitText(fullText, 1)
                } else {
                    var offset = 0
                    while (offset < fullText.length) {
                        val end = minOf(offset + COMMIT_CHUNK_SIZE, fullText.length)
                        val chunk = fullText.substring(offset, end)
                        ic.commitText(chunk, 1)
                        offset = end
                    }
                }
                val sizeKb = fullText.toByteArray(Charsets.UTF_8).size / 1024
                showToast("已粘贴 ${sizeKb}KB")
            } catch (e: Exception) {
                Log.e(TAG, "提交文本失败", e)
                showToast("粘贴失败：${e.message}")
            }
        }
    }

    private fun switchToDefaultIme() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE)
                    as android.view.inputmethod.InputMethodManager
            imm.showInputMethodPicker()
        } catch (e: Exception) {
            showToast("请手动到系统设置切换输入法")
        }
    }

    private fun showToast(msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }
}