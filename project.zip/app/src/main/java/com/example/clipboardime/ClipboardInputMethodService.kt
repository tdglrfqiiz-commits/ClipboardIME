package com.example.clipboardime

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.ImageButton
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.clipboardime.data.ClipEntity
import com.example.clipboardime.data.ClipRepository
import com.example.clipboardime.ui.ClipAdapter
import com.example.clipboardime.util.ClipboardReader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ClipboardInputMethodService : InputMethodService() {

    companion object {
        private const val TAG = "ClipIME"
        private const val COMMIT_CHUNK_SIZE = 256 * 1024
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var repository: ClipRepository
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var adapter: ClipAdapter

    private var currentList: List<ClipEntity> = emptyList()

    // 用于去重的变量
    private var lastSavedText: String? = null
    private var lastSaveTime: Long = 0L

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val text = ClipboardReader.readText(this, clipboardManager) ?: return@OnPrimaryClipChangedListener
        if (text.isBlank()) return@OnPrimaryClipChangedListener

        val now = System.currentTimeMillis()
        if (text == lastSavedText && now - lastSaveTime < 1000) {
            Log.d(TAG, "重复的剪贴板内容，已忽略")
            return@OnPrimaryClipChangedListener
        }
        lastSavedText = text
        lastSaveTime = now

        scope.launch {
            repository.save(text)
            refreshList()
        }
    }

    override fun onCreate() {
        super.onCreate()
        repository = ClipRepository(this)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        clipboardManager.removePrimaryClipChangedListener(clipListener)
        scope.cancel()
    }

    /**
     * ★ 核心修复：每次输入法显示时，强制限制其窗口高度为屏幕的 40%
     * 注意：InputMethodService 的 window 是 Dialog 类型，必须用 window?.window 才能拿到真正的 Window 对象。
     */
    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        
        // 获取屏幕高度，计算目标高度（屏幕的 40%）
        val screenHeight = resources.displayMetrics.heightPixels
        val targetHeight = (screenHeight * 0.4).toInt()
        
        // ★ 修复编译错误：这里的 window 是 Dialog，window?.window 才是真正的窗口
        window?.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, targetHeight)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.ime_clipboard, null)

        // ★ 二次保险：直接给视图本身也强制设置固定高度
        val screenHeight = resources.displayMetrics.heightPixels
        val targetHeight = (screenHeight * 0.4).toInt()
        view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, targetHeight)

        val recycler = view.findViewById<RecyclerView>(R.id.clip_recycler)
        adapter = ClipAdapter(
            onItemClick = { entity -> commitClipText(entity) },
            onDeleteClick = { entity -> deleteClip(entity) },
            onPinClick = { entity -> togglePin(entity) }
        )
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val switchBtn = view.findViewById<ImageButton>(R.id.btn_switch_ime)
        switchBtn.setOnClickListener { switchToDefaultIme() }

        // ★ 新增：顶部拖拽条的下拉关闭手势监听
        val dragHandle = view.findViewById<View>(R.id.drag_handle)
        setupDragToClose(dragHandle)

        refreshList()
        return view
    }

    /**
     * 设置下拉关闭手势
     * 当手指在顶部拖拽条上向下滑动超过一定距离时，隐藏输入法
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupDragToClose(dragHandle: View) {
        var startY = 0f
        // 触发下拉关闭的阈值，换算成像素（这里设置为 120dp 的滑动距离）
        val threshold = 120 * resources.displayMetrics.density

        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val deltaY = event.rawY - startY
                    if (deltaY > threshold) {
                        // 向下滑动超过阈值，关闭输入法
                        requestHideSelf(0)
                        true
                    } else {
                        false
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    startY = 0f
                    false
                }
                else -> false
            }
        }
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        val text = ClipboardReader.readText(this, clipboardManager)
        if (!text.isNullOrBlank()) {
            val now = System.currentTimeMillis()
            if (text != lastSavedText || now - lastSaveTime >= 1000) {
                lastSavedText = text
                lastSaveTime = now
                scope.launch {
                    repository.save(text)
                    refreshList()
                }
            }
        }
    }

    private fun refreshList() {
        scope.launch {
            currentList = repository.getAll()
            adapter.submit(currentList)
        }
    }

    private fun deleteClip(entity: ClipEntity) {
        scope.launch {
            repository.delete(entity)
            refreshList()
        }
    }

    private fun togglePin(entity: ClipEntity) {
        scope.launch {
            repository.togglePin(entity)
            refreshList()
        }
    }

    private fun commitClipText(entity: ClipEntity) {
        scope.launch {
            val fullText = withContext(Dispatchers.IO) {
                repository.getFullText(entity)
            }
            if (fullText.isEmpty()) {
                showToast("内容为空")
                return@launch
            }

            val ic: InputConnection = currentInputConnection ?: run {
                showToast("当前没有可输入的输入框")
                return@launch
            }

            try {
                if (fullText.length <= COMMIT_CHUNK_SIZE) {
                    ic.commitText(fullText, 1)
                } else {
                    var offset = 0
                    while (offset < fullText.length) {
                        val end = minOf(offset + COMMIT_CHUNK_SIZE, fullText.length)
                        val chunk = fullText.substring(offset, end)
                        ic.commitText(chunk, 1)
                        offset = end
                    }
                }
                val sizeKb = fullText.toByteArray(Charsets.UTF_8).size / 1024
                showToast("已粘贴 ${sizeKb}KB")
            } catch (e: Exception) {
                Log.e(TAG, "提交文本失败", e)
                showToast("粘贴失败：${e.message}")
            }
        }
    }

    private fun switchToDefaultIme() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE)
                    as android.view.inputmethod.InputMethodManager
            imm.showInputMethodPicker()
        } catch (e: Exception) {
            showToast("请手动到系统设置切换输入法")
        }
    }

    private fun showToast(msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }
}