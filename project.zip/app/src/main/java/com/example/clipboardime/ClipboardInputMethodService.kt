package com.example.clipboardime

import android.content.ClipboardManager
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.ImageButton
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.clipboardime.data.ClipEntity
import com.example.clipboardime.data.ClipRepository
import com.example.clipboardime.ui.ClipAdapter
import com.example.clipboardime.util.ClipboardReader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ClipboardInputMethodService : InputMethodService() {

    companion object {
        private const val TAG = "ClipIME"
        private const val COMMIT_CHUNK_SIZE = 256 * 1024
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var repository: ClipRepository
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var adapter: ClipAdapter

    private var currentList: List<ClipEntity> = emptyList()

    // ★ 新增：用于去重的变量
    private var lastSavedText: String? = null
    private var lastSaveTime: Long = 0L

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val text = ClipboardReader.readText(this, clipboardManager) ?: return@OnPrimaryClipChangedListener
        if (text.isBlank()) return@OnPrimaryClipChangedListener

        // ★ 防重复机制：如果内容和1秒内上一次完全相同，直接忽略
        val now = System.currentTimeMillis()
        if (text == lastSavedText && now - lastSaveTime < 1000) {
            Log.d(TAG, "重复的剪贴板内容，已忽略")
            return@OnPrimaryClipChangedListener
        }
        lastSavedText = text
        lastSaveTime = now

        scope.launch {
            repository.save(text)
            refreshList()
        }
    }

    override fun onCreate() {
        super.onCreate()
        repository = ClipRepository(this)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager.addPrimaryClipChangedListener(clipListener)
    }

    override fun onDestroy() {
        super.onDestroy()
        clipboardManager.removePrimaryClipChangedListener(clipListener)
        scope.cancel()
    }

    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.ime_clipboard, null)

        // ★ 核心修复：动态限制输入法高度为屏幕高度的40%，防止无限拉长遮挡屏幕
        val metrics = resources.displayMetrics
        val targetHeight = (metrics.heightPixels * 0.4).toInt()
        view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, targetHeight)

        val recycler = view.findViewById<RecyclerView>(R.id.clip_recycler)
        adapter = ClipAdapter(
            onItemClick = { entity -> commitClipText(entity) },
            onDeleteClick = { entity -> deleteClip(entity) },
            onPinClick = { entity -> togglePin(entity) }
        )
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val switchBtn = view.findViewById<ImageButton>(R.id.btn_switch_ime)
        switchBtn.setOnClickListener { switchToDefaultIme() }

        refreshList()
        return view
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        val text = ClipboardReader.readText(this, clipboardManager)
        if (!text.isNullOrBlank()) {
            // ★ 同样应用防抖逻辑，防止与剪贴板监听器双重触发
            val now = System.currentTimeMillis()
            if (text != lastSavedText || now - lastSaveTime >= 1000) {
                lastSavedText = text
                lastSaveTime = now
                scope.launch {
                    repository.save(text)
                    refreshList()
                }
            }
        }
    }

    private fun refreshList() {
        scope.launch {
            currentList = repository.getAll()
            adapter.submit(currentList)
        }
    }

    private fun deleteClip(entity: ClipEntity) {
        scope.launch {
            repository.delete(entity)
            refreshList()
        }
    }

    private fun togglePin(entity: ClipEntity) {
        scope.launch {
            repository.togglePin(entity)
            refreshList()
        }
    }

    private fun commitClipText(entity: ClipEntity) {
        scope.launch {
            val fullText = withContext(Dispatchers.IO) {
                repository.getFullText(entity)
            }
            if (fullText.isEmpty()) {
                showToast("内容为空")
                return@launch
            }

            val ic: InputConnection = currentInputConnection ?: run {
                showToast("当前没有可输入的输入框")
                return@launch
            }

            try {
                if (fullText.length <= COMMIT_CHUNK_SIZE) {
                    ic.commitText(fullText, 1)
                } else {
                    var offset = 0
                    while (offset < fullText.length) {
                        val end = minOf(offset + COMMIT_CHUNK_SIZE, fullText.length)
                        val chunk = fullText.substring(offset, end)
                        ic.commitText(chunk, 1)
                        offset = end
                    }
                }
                val sizeKb = fullText.toByteArray(Charsets.UTF_8).size / 1024
                showToast("已粘贴 ${sizeKb}KB")
            } catch (e: Exception) {
                Log.e(TAG, "提交文本失败", e)
                showToast("粘贴失败：${e.message}")
            }
        }
    }

    private fun switchToDefaultIme() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE)
                    as android.view.inputmethod.InputMethodManager
            imm.showInputMethodPicker()
        } catch (e: Exception) {
            showToast("请手动到系统设置切换输入法")
        }
    }

    private fun showToast(msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }
}