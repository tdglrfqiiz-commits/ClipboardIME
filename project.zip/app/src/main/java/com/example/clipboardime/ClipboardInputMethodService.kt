package com.example.clipboardime

import android.content.ClipboardManager
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.clipboardime.data.ClipEntity
import com.example.clipboardime.data.ClipRepository
import com.example.clipboardime.ui.ClipAdapter
import com.example.clipboardime.util.ClipboardReader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 无限剪贴板历史输入法 —— 核心服务。
 *
 * 职责：
 * 1. 监听系统剪贴板变化，自动保存到 Room 数据库。
 * 2. 提供只含历史列表的输入法界面（无字母键盘）。
 * 3. 点击列表项 → 读取完整文本 → 通过 InputConnection 提交到当前输入框。
 * 4. 大文本分块提交，避免 Binder TransactionTooLargeException。
 */
class ClipboardInputMethodService : InputMethodService() {

    companion object {
        private const val TAG = "ClipIME"

        /** 分块提交的块大小：256KB（字符数，不是字节数）。
         *  Binder 事务缓冲区约 1MB，256K 字符足够安全。 */
        private const val COMMIT_CHUNK_SIZE = 256 * 1024
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var repository: ClipRepository
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var adapter: ClipAdapter

    /** 当前界面上的搜索结果缓存 */
    private var currentList: List<ClipEntity> = emptyList()

    // ==================== 剪贴板监听 ====================

    /**
     * 剪贴板变化监听器。
     * 每次复制后自动被调用，把文本存进数据库。
     */
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val text = ClipboardReader.readText(this, clipboardManager) ?: return@OnPrimaryClipChangedListener
        if (text.isBlank()) return@OnPrimaryClipChangedListener

        scope.launch {
            repository.save(text)
            // 如果界面正在显示，刷新列表
            refreshList()
        }
    }

    // ==================== 生命周期 ====================

    override fun onCreate() {
        super.onCreate()
        repository = ClipRepository(this)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        // 注册剪贴板监听
        clipboardManager.addPrimaryClipChangedListener(clipListener)
        Log.d(TAG, "输入法服务已创建，剪贴板监听已注册")
    }

    override fun onDestroy() {
        super.onDestroy()
        clipboardManager.removePrimaryClipChangedListener(clipListener)
        scope.cancel()
        Log.d(TAG, "输入法服务已销毁")
    }

    // ==================== 输入法界面 ====================

    /**
     * 系统需要输入法界面时调用。
     * 这里创建只包含“搜索框 + 历史列表 + 切换按钮”的视图。
     */
    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.ime_clipboard, null)

        // 1. 搜索框
        val searchBox = view.findViewById<EditText>(R.id.search_box)

        // 2. RecyclerView
        val recycler = view.findViewById<RecyclerView>(R.id.clip_recycler)
        adapter = ClipAdapter(
            onItemClick = { entity -> commitClipText(entity) },
            onDeleteClick = { entity -> deleteClip(entity) },
            onPinClick = { entity -> togglePin(entity) }
        )
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        // 3. 切换回原输入法按钮
        val switchBtn = view.findViewById<ImageButton>(R.id.btn_switch_ime)
        switchBtn.setOnClickListener { switchToDefaultIme() }

        // 4. 监听搜索输入
        searchBox.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val keyword = s?.toString()?.trim().orEmpty()
                scope.launch {
                    currentList = if (keyword.isEmpty()) {
                        repository.getAll()
                    } else {
                        repository.search(keyword)
                    }
                    adapter.submit(currentList)
                }
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // 初始加载
        refreshList()

        return view
    }

    /**
     * 每次输入框获得焦点时触发。
     * 这里做一次“补读”：如果复制发生在输入法进程未运行时，
     * 剪贴板监听器不会被调用，所以在这里主动读一次剪贴板。
     */
    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        // 补读剪贴板（覆盖“键盘进程不在时复制”的情况）
        val text = ClipboardReader.readText(this, clipboardManager)
        if (!text.isNullOrBlank()) {
            scope.launch {
                repository.save(text)
                refreshList()
            }
        }
    }

    // ==================== 数据操作 ====================

    /** 刷新列表（从数据库重新加载） */
    private fun refreshList() {
        scope.launch {
            currentList = repository.getAll()
            adapter.submit(currentList)
        }
    }

    /** 删除一条记录 */
    private fun deleteClip(entity: ClipEntity) {
        scope.launch {
            repository.delete(entity)
            refreshList()
        }
    }

    /** 切换置顶 */
    private fun togglePin(entity: ClipEntity) {
        scope.launch {
            repository.togglePin(entity)
            refreshList()
        }
    }

    // ==================== 核心：完整文本提交 ====================

    /**
     * 点击列表项时调用。
     * 读取完整文本 → 分块提交到当前输入框。
     *
     * 大文本处理策略：
     * - 如果文本 ≤ 256K 字符，一次 commitText 提交。
     * - 如果更大，切成 256K 字符的块，循环 commitText，
     *   避免 Binder 事务缓冲区溢出（TransactionTooLargeException）。
     */
    private fun commitClipText(entity: ClipEntity) {
        scope.launch {
            // 1. 获取完整文本（超大文本会从文件加载）
            val fullText = withContext(Dispatchers.IO) {
                repository.getFullText(entity)
            }
            if (fullText.isEmpty()) {
                showToast("内容为空")
                return@launch
            }

            // 2. 获取当前输入连接
            val ic: InputConnection = currentInputConnection ?: run {
                showToast("当前没有可输入的输入框")
                return@launch
            }

            // 3. 分块提交
            try {
                if (fullText.length <= COMMIT_CHUNK_SIZE) {
                    // 小文本：一次提交
                    ic.commitText(fullText, 1)
                } else {
                    // 大文本：分块循环提交
                    var offset = 0
                    while (offset < fullText.length) {
                        val end = minOf(offset + COMMIT_CHUNK_SIZE, fullText.length)
                        val chunk = fullText.substring(offset, end)
                        // newCursorPosition=1 表示光标移到本块末尾之后
                        ic.commitText(chunk, 1)
                        offset = end
                    }
                }
                val sizeKb = fullText.toByteArray(Charsets.UTF_8).size / 1024
                showToast("已粘贴 ${sizeKb}KB")
            } catch (e: Exception) {
                Log.e(TAG, "提交文本失败", e)
                showToast("粘贴失败：${e.message}")
            }
        }
    }

    // ==================== 切换回原输入法 ====================

    /**
     * 弹出系统输入法选择器。
     * Android 不允许应用直接静默切换输入法（安全限制），
     * 只能弹出选择器让用户手动选择。
     */
    private fun switchToDefaultIme() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE)
                    as android.view.inputmethod.InputMethodManager
            imm.showInputMethodPicker()
        } catch (e: Exception) {
            Log.e(TAG, "切换输入法失败", e)
            showToast("请手动到系统设置切换输入法")
        }
    }

    private fun showToast(msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }
}