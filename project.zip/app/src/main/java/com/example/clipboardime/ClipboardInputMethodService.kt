package com.example.clipboardime

import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.ImageButton
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.clipboardime.data.ClipEntity
import com.example.clipboardime.data.ClipRepository
import com.example.clipboardime.ui.ClipAdapter
import com.example.clipboardime.util.ClipboardReader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ClipboardInputMethodService : InputMethodService() {

    companion object {
        private const val TAG = "ClipIME"
        private const val COMMIT_CHUNK_SIZE = 256 * 1024
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var repository: ClipRepository
    private lateinit var clipboardManager: ClipboardManager
    private lateinit var adapter: ClipAdapter

    private var currentList: List<ClipEntity> = emptyList()
    private var lastSavedText: String? = null
    private var lastSaveTime: Long = 0L

    private var inputView: View? = null

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val text = ClipboardReader.readText(this, clipboardManager) ?: return@OnPrimaryClipChangedListener
        if (text.isBlank()) return@OnPrimaryClipChangedListener

        val now = System.currentTimeMillis()
        if (text == lastSavedText && now - lastSaveTime < 1000) {
            return@OnPrimaryClipChangedListener
        }
        lastSavedText = text
        lastSaveTime = now

        scope.launch {
            repository.save(text)
            refreshList()
        }
    }

    override fun onCreate() {
        super.onCreate()
        repository = ClipRepository(this)
        clipboardManager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboardManager.addPrimaryClipChangedListener(clipListener)

        val initialText = ClipboardReader.readText(this, clipboardManager)
        if (!initialText.isNullOrBlank()) {
            lastSavedText = initialText
            lastSaveTime = System.currentTimeMillis()
            scope.launch { repository.save(initialText) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        clipboardManager.removePrimaryClipChangedListener(clipListener)
        scope.cancel()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val screenHeight = resources.displayMetrics.heightPixels
        val targetHeight = (screenHeight * 0.4).toInt()

        // ★ 重置视图和窗口的位置，防止上次拖拽残留
        inputView?.translationY = 0f
        val params = window?.window?.attributes
        if (params != null) {
            params.y = 0
            window?.window?.attributes = params
        }

        // ★ 核心：设置窗口背景为透明，并将窗口高度限制为屏幕 40%
        window?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, targetHeight)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.ime_clipboard, null)
        inputView = view

        // 视图高度与窗口高度保持一致
        val screenHeight = resources.displayMetrics.heightPixels
        val targetHeight = (screenHeight * 0.4).toInt()
        view.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, targetHeight)

        // ★ 窗口背景透明，背景色全部由 XML 根布局提供
        window?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val recycler = view.findViewById<RecyclerView>(R.id.clip_recycler)
        adapter = ClipAdapter(
            onItemClick = { entity -> commitClipText(entity) },
            onDeleteClick = { entity -> deleteClip(entity) },
            onPinClick = { entity -> togglePin(entity) }
        )
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val switchBtn = view.findViewById<ImageButton>(R.id.btn_switch_ime)
        switchBtn.setOnClickListener { switchToDefaultIme() }

        val dragHandle = view.findViewById<View>(R.id.drag_handle)
        setupDragToClose(dragHandle)

        refreshList()
        return view
    }

    /**
     * ★ 核心修复：跟手拖拽 + 移动整个窗口
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupDragToClose(dragHandle: View) {
        var startY = 0f
        var initialWindowY = 0
        val dismissThreshold = maxOf(resources.displayMetrics.heightPixels / 4, 200)

        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = event.rawY
                    // 记录窗口初始的 Y 坐标
                    initialWindowY = window?.window?.attributes?.y ?: 0
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = event.rawY - startY
                    if (dy > 0) {
                        // ★ 核心：修改窗口的 Y 坐标，让整个窗口（包含白色背景框）一起滑动
                        val params = window?.window?.attributes
                        if (params != null) {
                            // 注意：由于 gravity 是 BOTTOM，向下滑动需要减去 dy
                            params.y = initialWindowY - dy.toInt()
                            window?.window?.attributes = params
                        }
                        // 同时设置视图的 translationY，保证内容与背景框不分离
                        inputView?.translationY = dy
                    } else {
                        // 禁止向上拉
                        inputView?.translationY = 0f
                        val params = window?.window?.attributes
                        if (params != null) {
                            params.y = initialWindowY
                            window?.window?.attributes = params
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val dy = event.rawY - startY
                    if (dy > dismissThreshold) {
                        // 滑动距离超过阈值，隐藏输入法
                        requestHideSelf(0)
                    } else {
                        // 没超过阈值，用动画把视图和窗口都平滑弹回原位
                        inputView?.animate()
                            ?.translationY(0f)
                            ?.setDuration(200)
                            ?.start()
                        
                        val params = window?.window?.attributes
                        if (params != null) {
                            params.y = initialWindowY
                            window?.window?.attributes = params
                        }
                    }
                    startY = 0f
                    true
                }
                else -> false
            }
        }
    }

    private fun refreshList() {
        scope.launch {
            currentList = repository.getAll()
            adapter.submit(currentList)
        }
    }

    private fun deleteClip(entity: ClipEntity) {
        scope.launch {
            repository.delete(entity)
            refreshList()
        }
    }

    private fun togglePin(entity: ClipEntity) {
        scope.launch {
            repository.togglePin(entity)
            refreshList()
        }
    }

    private fun commitClipText(entity: ClipEntity) {
        scope.launch {
            val fullText = withContext(Dispatchers.IO) {
                repository.getFullText(entity)
            }
            if (fullText.isEmpty()) {
                showToast("内容为空")
                return@launch
            }

            val ic: InputConnection = currentInputConnection ?: run {
                showToast("当前没有可输入的输入框")
                return@launch
            }

            try {
                if (fullText.length <= COMMIT_CHUNK_SIZE) {
                    ic.commitText(fullText, 1)
                } else {
                    var offset = 0
                    while (offset < fullText.length) {
                        val end = minOf(offset + COMMIT_CHUNK_SIZE, fullText.length)
                        val chunk = fullText.substring(offset, end)
                        ic.commitText(chunk, 1)
                        offset = end
                    }
                }
                val sizeKb = fullText.toByteArray(Charsets.UTF_8).size / 1024
                showToast("已粘贴 ${sizeKb}KB")
            } catch (e: Exception) {
                Log.e(TAG, "提交文本失败", e)
                showToast("粘贴失败：${e.message}")
            }
        }
    }

    private fun switchToDefaultIme() {
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE)
                    as android.view.inputmethod.InputMethodManager
            imm.showInputMethodPicker()
        } catch (e: Exception) {
            showToast("请手动到系统设置切换输入法")
        }
    }

    private fun showToast(msg: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }
}